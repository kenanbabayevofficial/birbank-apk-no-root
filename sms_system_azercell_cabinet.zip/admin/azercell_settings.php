<?php
session_start();
require_once "../config/database.php";
require_once "../config/azercell_config.php";

if (!isset($_SESSION["admin_logged_in"]) || $_SESSION["admin_logged_in"] !== true) {
    header("Location: login.php");
    exit;
}

$message = "";
$message_type = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    try {
        $pdo = getDBConnection();
        
        if (isset($_POST["test_connection"])) {
            $username = trim($_POST["test_username"]);
            $password = trim($_POST["test_password"]);
            
            if (empty($username) || empty($password)) {
                $message = "Zəhmət olmasa test məlumatlarını doldurun!";
                $message_type = "warning";
            } else {
                $azercell = new AzercellCabinet();
                $result = $azercell->login($username, $password);
                
                if ($result["success"]) {
                    $balance_result = $azercell->checkBalance();
                    $azercell->logout();
                    
                    $message = "Bağlantı uğurlu! Balans: " . ($balance_result["success"] ? $balance_result["balance"] . " " . $balance_result["currency"] : "Məlumat alına bilmədi");
                    $message_type = "success";
                } else {
                    $message = "Bağlantı uğursuz: " . $result["error"];
                    $message_type = "danger";
                }
            }
        } elseif (isset($_POST["save_settings"])) {
            $default_username = trim($_POST["default_username"]);
            $default_sender_id = trim($_POST["default_sender_id"]);
            $auto_login = isset($_POST["auto_login"]) ? 1 : 0;
            
            $stmt = $pdo->prepare("INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
            
            $stmt->execute(["azercell_default_username", $default_username]);
            $stmt->execute(["azercell_default_sender_id", $default_sender_id]);
            $stmt->execute(["azercell_auto_login", $auto_login]);
            
            $message = "Tənzimləmələr uğurla saxlanıldı!";
            $message_type = "success";
        }
        
    } catch (Exception $e) {
        $message = "Xəta: " . $e->getMessage();
        $message_type = "danger";
    }
}

try {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT setting_key, setting_value FROM system_settings WHERE setting_key IN (\"azercell_default_username\", \"azercell_default_sender_id\", \"azercell_auto_login\")");
    $stmt->execute();
    $settings = [];
    while ($row = $stmt->fetch()) {
        $settings[$row["setting_key"]] = $row["setting_value"];
    }
} catch (Exception $e) {
    $settings = [];
}
?>

<!DOCTYPE html>
<html lang="az">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Azercell Kabinet Tənzimləmələri - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .sidebar { background: #343a40; min-height: 100vh; }
        .sidebar .nav-link { color: #adb5bd; }
        .sidebar .nav-link.active { background: #495057; color: white; }
        .main-content { background: white; border-radius: 10px; box-shadow: 0 0 15px rgba(0,0,0,0.1); }
        .azercell-header { background: linear-gradient(45deg, #ff6b35, #f7931e); color: white; padding: 20px; border-radius: 10px 10px 0 0; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3 col-lg-2 sidebar p-0">
                <div class="p-3">
                    <h5 class="text-white"><i class="fas fa-cog me-2"></i>Admin Panel</h5>
                </div>
                <nav class="nav flex-column">
                    <a class="nav-link" href="dashboard.php"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                    <a class="nav-link" href="sms_logs.php"><i class="fas fa-list me-2"></i>SMS Logları</a>
                    <a class="nav-link active" href="azercell_settings.php"><i class="fas fa-building me-2"></i>Azercell Kabinet</a>
                    <a class="nav-link" href="system_settings.php"><i class="fas fa-cogs me-2"></i>Sistem Tənzimləmələri</a>
                    <a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Çıxış</a>
                </nav>
            </div>

            <div class="col-md-9 col-lg-10 p-4">
                <div class="main-content">
                    <div class="azercell-header">
                        <h4 class="mb-0"><i class="fas fa-building me-2"></i>Azercell Kabinet Tənzimləmələri</h4>
                        <small>Azercell kabinet sistemi konfiqurasiyası</small>
                    </div>

                    <div class="p-4">
                        <?php if ($message): ?>
                            <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
                                <?php echo $message; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>

                        <div class="row">
                            <div class="col-md-6 mb-4">
                                <div class="card">
                                    <div class="card-header">
                                        <h6 class="mb-0"><i class="fas fa-plug me-2"></i>Test Bağlantısı</h6>
                                    </div>
                                    <div class="card-body">
                                        <form method="POST">
                                            <div class="mb-3">
                                                <label for="test_username" class="form-label">Test İstifadəçi Adı</label>
                                                <input type="text" class="form-control" id="test_username" name="test_username" placeholder="Azercell kabinet istifadəçi adı">
                                            </div>
                                            <div class="mb-3">
                                                <label for="test_password" class="form-label">Test Şifrə</label>
                                                <input type="password" class="form-control" id="test_password" name="test_password" placeholder="Azercell kabinet şifrəsi">
                                            </div>
                                            <button type="submit" name="test_connection" class="btn btn-primary">
                                                <i class="fas fa-test-tube me-2"></i>Bağlantını Test Et
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6 mb-4">
                                <div class="card">
                                    <div class="card-header">
                                        <h6 class="mb-0"><i class="fas fa-cogs me-2"></i>Varsayılan Tənzimləmələr</h6>
                                    </div>
                                    <div class="card-body">
                                        <form method="POST">
                                            <div class="mb-3">
                                                <label for="default_username" class="form-label">Varsayılan İstifadəçi Adı</label>
                                                <input type="text" class="form-control" id="default_username" name="default_username" value="<?php echo $settings["azercell_default_username"] ?? ""; ?>" placeholder="Varsayılan istifadəçi adı">
                                                <div class="form-text">İstifadəçilər üçün varsayılan istifadəçi adı</div>
                                            </div>
                                            <div class="mb-3">
                                                <label for="default_sender_id" class="form-label">Varsayılan Göndərən Adı</label>
                                                <input type="text" class="form-control" id="default_sender_id" name="default_sender_id" value="<?php echo $settings["azercell_default_sender_id"] ?? "Azercell"; ?>" placeholder="Varsayılan göndərən adı">
                                                <div class="form-text">SMS-lərdə görünəcək varsayılan ad</div>
                                            </div>
                                            <div class="mb-3">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" id="auto_login" name="auto_login" <?php echo ($settings["azercell_auto_login"] ?? 0) ? "checked" : ""; ?>>
                                                    <label class="form-check-label" for="auto_login">Avtomatik Giriş</label>
                                                </div>
                                                <div class="form-text">Varsayılan məlumatlarla avtomatik giriş</div>
                                            </div>
                                            <button type="submit" name="save_settings" class="btn btn-success">
                                                <i class="fas fa-save me-2"></i>Tənzimləmələri Saxla
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h6 class="mb-0"><i class="fas fa-info-circle me-2"></i>Azercell Kabinet Məlumatları</h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <h6>Dəstəklənən Nömrələr:</h6>
                                                <ul>
                                                    <li><strong>Azercell:</strong> 050, 051, 077</li>
                                                    <li><strong>Bakcell:</strong> 055, 099</li>
                                                    <li><strong>Nar:</strong> 070</li>
                                                </ul>
                                            </div>
                                            <div class="col-md-6">
                                                <h6>Texniki Məlumatlar:</h6>
                                                <ul>
                                                    <li><strong>Login URL:</strong> https://kabinetim.azercell.com/login</li>
                                                    <li><strong>SMS URL:</strong> https://kabinetim.azercell.com/catalog/web-sms</li>
                                                    <li><strong>Status:</strong> <span class="badge bg-success">Aktiv</span></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
