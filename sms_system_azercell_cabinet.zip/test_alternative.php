<?php
echo "<h2>Alternativ SMS Test - HTTP 405 Həlli</h2>";

echo "<h3>HTTP 405 xətası üçün alternativ metodlar:</h3>";
echo "<p><strong>Problem:</strong> HTTP 405 \"Method Not Allowed\" - POST metodu qəbul edilmir</p>";
echo "<p><strong>Həll:</strong> Fərqli metodlar və başlıqlar istifadə edəcəyik</p>";

$username = "your_username";
$password = "your_password";
$phone = "+994501234567";
$message = "Test mesajı";
$sender = "Test";

echo "<form method=\"POST\">";
echo "<p>İstifadəçi Adı: <input type=\"text\" name=\"username\" value=\"$username\"></p>";
echo "<p>Şifrə: <input type=\"password\" name=\"password\" value=\"$password\"></p>";
echo "<p>Telefon: <input type=\"text\" name=\"phone\" value=\"$phone\"></p>";
echo "<p>Mesaj: <textarea name=\"message\">$message</textarea></p>";
echo "<p>Göndərən: <input type=\"text\" name=\"sender\" value=\"$sender\"></p>";
echo "<button type=\"submit\" name=\"test_method1\">Metod 1: GET ilə test</button><br><br>";
echo "<button type=\"submit\" name=\"test_method2\">Metod 2: POST başlıqları ilə</button><br><br>";
echo "<button type=\"submit\" name=\"test_method3\">Metod 3: JSON ilə</button><br><br>";
echo "<button type=\"submit\" name=\"test_method4\">Metod 4: Sadə cURL</button>";
echo "</form>";

if ($_POST) {
    $username = $_POST["username"];
    $password = $_POST["password"];
    $phone = $_POST["phone"];
    $message = $_POST["message"];
    $sender = $_POST["sender"];
    
    if (isset($_POST["test_method1"])) {
        echo "<h3>Metod 1: GET ilə test</h3>";
        testMethod1($username, $password, $phone, $message, $sender);
    } elseif (isset($_POST["test_method2"])) {
        echo "<h3>Metod 2: POST başlıqları ilə</h3>";
        testMethod2($username, $password, $phone, $message, $sender);
    } elseif (isset($_POST["test_method3"])) {
        echo "<h3>Metod 3: JSON ilə</h3>";
        testMethod3($username, $password, $phone, $message, $sender);
    } elseif (isset($_POST["test_method4"])) {
        echo "<h3>Metod 4: Sadə cURL</h3>";
        testMethod4($username, $password, $phone, $message, $sender);
    }
}

function testMethod1($username, $password, $phone, $message, $sender) {
    echo "<p><strong>GET metodu ilə səhifəni yoxlayırıq...</strong></p>";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://kabinetim.azercell.com/login");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");
    curl_setopt($ch, CURLOPT_HEADER, true);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    echo "<p><strong>HTTP Code:</strong> $http_code</p>";
    echo "<p><strong>Response Preview:</strong></p>";
    echo "<pre>" . substr($response, 0, 1000) . "</pre>";
}

function testMethod2($username, $password, $phone, $message, $sender) {
    echo "<p><strong>POST başlıqları ilə test...</strong></p>";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://kabinetim.azercell.com/login");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        "username" => $username,
        "password" => $password
    ]));
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type: application/x-www-form-urlencoded",
        "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language: az-AZ,az;q=0.8,en-US;q=0.5,en;q=0.3",
        "Accept-Encoding: gzip, deflate",
        "Connection: keep-alive",
        "Upgrade-Insecure-Requests: 1"
    ]);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $final_url = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    curl_close($ch);
    
    echo "<p><strong>HTTP Code:</strong> $http_code</p>";
    echo "<p><strong>Final URL:</strong> $final_url</p>";
    echo "<p><strong>Response Preview:</strong></p>";
    echo "<pre>" . substr($response, 0, 1000) . "</pre>";
}

function testMethod3($username, $password, $phone, $message, $sender) {
    echo "<p><strong>JSON formatı ilə test...</strong></p>";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://kabinetim.azercell.com/login");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
        "username" => $username,
        "password" => $password
    ]));
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type: application/json",
        "Accept: application/json, text/plain, */*",
        "X-Requested-With: XMLHttpRequest"
    ]);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    echo "<p><strong>HTTP Code:</strong> $http_code</p>";
    echo "<p><strong>Response Preview:</strong></p>";
    echo "<pre>" . substr($response, 0, 1000) . "</pre>";
}

function testMethod4($username, $password, $phone, $message, $sender) {
    echo "<p><strong>Sadə cURL ilə test...</strong></p>";
    
    if (!is_dir("cookies")) {
        mkdir("cookies", 0755, true);
    }
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://kabinetim.azercell.com");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");
    curl_setopt($ch, CURLOPT_COOKIEJAR, "cookies/test_cookies.txt");
    curl_setopt($ch, CURLOPT_COOKIEFILE, "cookies/test_cookies.txt");
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    echo "<p><strong>Ana səhifə HTTP Code:</strong> $http_code</p>";
    
    if ($http_code === 200) {
        echo "<p style=\"color: green;\">✓ Ana səhifə yükləndi</p>";
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://kabinetim.azercell.com/login");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");
        curl_setopt($ch, CURLOPT_COOKIEJAR, "cookies/test_cookies.txt");
        curl_setopt($ch, CURLOPT_COOKIEFILE, "cookies/test_cookies.txt");
        curl_setopt($ch, CURLOPT_REFERER, "https://kabinetim.azercell.com");
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        echo "<p><strong>Login səhifə HTTP Code:</strong> $http_code</p>";
        
        if ($http_code === 200) {
            echo "<p style=\"color: green;\">✓ Login səhifəsi yükləndi</p>";
            echo "<p><strong>Login səhifəsi məzmunu:</strong></p>";
            echo "<pre>" . substr($response, 0, 500) . "</pre>";
        } else {
            echo "<p style=\"color: red;\">✗ Login səhifəsi yüklənmədi</p>";
        }
    } else {
        echo "<p style=\"color: red;\">✗ Ana səhifə yüklənmədi</p>";
    }
}
?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
pre { background: #f5f5f5; padding: 10px; border-radius: 5px; overflow-x: auto; }
input, textarea { width: 300px; padding: 5px; margin: 5px 0; }
button { padding: 10px 20px; margin: 5px; background: #007bff; color: white; border: none; cursor: pointer; }
button:hover { background: #0056b3; }
</style>
