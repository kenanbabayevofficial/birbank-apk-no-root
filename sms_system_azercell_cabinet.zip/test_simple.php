<?php
echo "<h2>Sadə SMS Test</h2>";

$username = "your_username";
$password = "your_password";
$phone = "+994501234567";
$message = "Test mesajı";
$sender = "Test";

echo "<p><strong>Test məlumatları:</strong></p>";
echo "<p>İstifadəçi: $username</p>";
echo "<p>Telefon: $phone</p>";
echo "<p>Mesaj: $message</p>";

echo "<form method=\"POST\">";
echo "<p>İstifadəçi Adı: <input type=\"text\" name=\"username\" value=\"$username\"></p>";
echo "<p>Şifrə: <input type=\"password\" name=\"password\" value=\"$password\"></p>";
echo "<p>Telefon: <input type=\"text\" name=\"phone\" value=\"$phone\"></p>";
echo "<p>Mesaj: <textarea name=\"message\">$message</textarea></p>";
echo "<p>Göndərən: <input type=\"text\" name=\"sender\" value=\"$sender\"></p>";
echo "<button type=\"submit\">Test Et</button>";
echo "</form>";

if ($_POST) {
    echo "<h3>Test Nəticəsi:</h3>";
    
    $username = $_POST["username"];
    $password = $_POST["password"];
    $phone = $_POST["phone"];
    $message = $_POST["message"];
    $sender = $_POST["sender"];
    
    try {
        require_once "config/azercell_config.php";
        
        $azercell = new AzercellCabinet();
        
        echo "<p><strong>1. Login test edilir...</strong></p>";
        $login_result = $azercell->login($username, $password);
        
        echo "<pre>";
        print_r($login_result);
        echo "</pre>";
        
        if ($login_result["success"]) {
            echo "<p style=\"color: green;\">✓ Login uğurlu!</p>";
            
            echo "<p><strong>2. SMS göndərilir...</strong></p>";
            $sms_result = $azercell->sendSms($phone, $message, $sender);
            
            echo "<pre>";
            print_r($sms_result);
            echo "</pre>";
            
            if ($sms_result["success"]) {
                echo "<p style=\"color: green;\">✓ SMS uğurla göndərildi!</p>";
            } else {
                echo "<p style=\"color: red;\">✗ SMS göndərilmədi: " . $sms_result["error"] . "</p>";
            }
            
            $azercell->logout();
            
        } else {
            echo "<p style=\"color: red;\">✗ Login uğursuz: " . $login_result["error"] . "</p>";
        }
        
    } catch (Exception $e) {
        echo "<p style=\"color: red;\">✗ Xəta: " . $e->getMessage() . "</p>";
    }
}
?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
pre { background: #f5f5f5; padding: 10px; border-radius: 5px; overflow-x: auto; }
input, textarea { width: 300px; padding: 5px; margin: 5px 0; }
button { padding: 10px 20px; background: #007bff; color: white; border: none; cursor: pointer; }
</style>
