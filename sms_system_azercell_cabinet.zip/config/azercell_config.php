<?php
// Azercell Kabinet Sistemi Konfiqurasiyası

// Azercell Kabinet URL-ləri
define("AZERCELL_LOGIN_URL", "https://kabinetim.azercell.com/login");
define("AZERCELL_SMS_URL", "https://kabinetim.azercell.com/catalog/web-sms");
define("AZERCELL_BASE_URL", "https://kabinetim.azercell.com");

// Session və Cookie parametrləri
define("AZERCELL_SESSION_NAME", "azercell_session");
define("AZERCELL_COOKIE_FILE", "cookies/azercell_cookies.txt");

// User Agent
define("AZERCELL_USER_AGENT", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36");

// Azercell Kabinet API funksiyaları
class AzercellCabinet {
    private $ch;
    private $cookie_file;
    private $is_logged_in = false;
    private $session_data = [];
    
    public function __construct() {
        $this->cookie_file = AZERCELL_COOKIE_FILE;
        $this->initCurl();
    }
    
    private function initCurl() {
        $this->ch = curl_init();
        curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($this->ch, CURLOPT_COOKIEJAR, $this->cookie_file);
        curl_setopt($this->ch, CURLOPT_COOKIEFILE, $this->cookie_file);
        curl_setopt($this->ch, CURLOPT_USERAGENT, AZERCELL_USER_AGENT);
        curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($this->ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($this->ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($this->ch, CURLOPT_HEADER, true);
    }
    
    public function login($username, $password) {
        try {
            curl_setopt($this->ch, CURLOPT_URL, AZERCELL_LOGIN_URL);
            curl_setopt($this->ch, CURLOPT_POST, false);
            
            $response = curl_exec($this->ch);
            $http_code = curl_getinfo($this->ch, CURLINFO_HTTP_CODE);
            
            if ($http_code !== 200) {
                return [
                    "success" => false,
                    "error" => "Login səhifəsi yüklənə bilmədi",
                    "http_code" => $http_code
                ];
            }
            
            preg_match("/<input[^>]*name=\"_token\"[^>]*value=\"([^\"]*)\"/", $response, $csrf_matches);
            $csrf_token = $csrf_matches[1] ?? "";
            
            $post_data = [
                "_token" => $csrf_token,
                "username" => $username,
                "password" => $password,
                "remember" => "1"
            ];
            
            curl_setopt($this->ch, CURLOPT_URL, AZERCELL_LOGIN_URL);
            curl_setopt($this->ch, CURLOPT_POST, true);
            curl_setopt($this->ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
            curl_setopt($this->ch, CURLOPT_HEADER, true);
            
            $response = curl_exec($this->ch);
            $http_code = curl_getinfo($this->ch, CURLINFO_HTTP_CODE);
            $final_url = curl_getinfo($this->ch, CURLINFO_EFFECTIVE_URL);
            
            if ($http_code === 200 && strpos($final_url, "dashboard") !== false) {
                $this->is_logged_in = true;
                return [
                    "success" => true,
                    "message" => "Uğurla giriş edildi",
                    "redirect_url" => $final_url
                ];
            } else {
                preg_match("/<div[^>]*class=\"[^\"]*alert[^\"]*\"[^>]*>(.*?)<\/div>/s", $response, $error_matches);
                $error_message = $error_matches[1] ?? "Giriş uğursuz oldu";
                
                return [
                    "success" => false,
                    "error" => strip_tags($error_message),
                    "http_code" => $http_code
                ];
            }
            
        } catch (Exception $e) {
            return [
                "success" => false,
                "error" => "Giriş xətası: " . $e->getMessage()
            ];
        }
    }
    
    public function sendSms($phone, $message, $sender_id = "") {
        if (!$this->is_logged_in) {
            return [
                "success" => false,
                "error" => "Əvvəlcə giriş etməlisiniz"
            ];
        }
        
        try {
            curl_setopt($this->ch, CURLOPT_URL, AZERCELL_SMS_URL);
            curl_setopt($this->ch, CURLOPT_POST, false);
            curl_setopt($this->ch, CURLOPT_HEADER, false);
            
            $response = curl_exec($this->ch);
            $http_code = curl_getinfo($this->ch, CURLINFO_HTTP_CODE);
            
            if ($http_code !== 200) {
                return [
                    "success" => false,
                    "error" => "SMS səhifəsi yüklənə bilmədi",
                    "http_code" => $http_code
                ];
            }
            
            preg_match("/<input[^>]*name=\"_token\"[^>]*value=\"([^\"]*)\"/", $response, $csrf_matches);
            $csrf_token = $csrf_matches[1] ?? "";
            
            $post_data = [
                "_token" => $csrf_token,
                "phone" => $phone,
                "message" => $message,
                "sender_id" => $sender_id ?: "Azercell",
                "submit" => "1"
            ];
            
            curl_setopt($this->ch, CURLOPT_URL, AZERCELL_SMS_URL);
            curl_setopt($this->ch, CURLOPT_POST, true);
            curl_setopt($this->ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
            curl_setopt($this->ch, CURLOPT_HEADER, true);
            
            $response = curl_exec($this->ch);
            $http_code = curl_getinfo($this->ch, CURLINFO_HTTP_CODE);
            
            if ($http_code === 200 && strpos($response, "success") !== false) {
                return [
                    "success" => true,
                    "message" => "SMS uğurla göndərildi",
                    "phone" => $phone,
                    "provider" => "Azercell Kabinet"
                ];
            } else {
                preg_match("/<div[^>]*class=\"[^\"]*alert[^\"]*\"[^>]*>(.*?)<\/div>/s", $response, $error_matches);
                $error_message = $error_matches[1] ?? "SMS göndərilmədi";
                
                return [
                    "success" => false,
                    "error" => strip_tags($error_message),
                    "http_code" => $http_code
                ];
            }
            
        } catch (Exception $e) {
            return [
                "success" => false,
                "error" => "SMS göndərmə xətası: " . $e->getMessage()
            ];
        }
    }
    
    public function checkBalance() {
        if (!$this->is_logged_in) {
            return [
                "success" => false,
                "error" => "Əvvəlcə giriş etməlisiniz"
            ];
        }
        
        try {
            curl_setopt($this->ch, CURLOPT_URL, AZERCELL_BASE_URL . "/dashboard");
            curl_setopt($this->ch, CURLOPT_POST, false);
            curl_setopt($this->ch, CURLOPT_HEADER, false);
            
            $response = curl_exec($this->ch);
            $http_code = curl_getinfo($this->ch, CURLINFO_HTTP_CODE);
            
            if ($http_code === 200) {
                preg_match("/<span[^>]*class=\"[^\"]*balance[^\"]*\"[^>]*>([^<]*)<\/span>/", $response, $balance_matches);
                $balance = $balance_matches[1] ?? "0";
                
                return [
                    "success" => true,
                    "balance" => trim($balance),
                    "currency" => "AZN"
                ];
            } else {
                return [
                    "success" => false,
                    "error" => "Balans məlumatı alına bilmədi",
                    "http_code" => $http_code
                ];
            }
            
        } catch (Exception $e) {
            return [
                "success" => false,
                "error" => "Balans yoxlama xətası: " . $e->getMessage()
            ];
        }
    }
    
    public function logout() {
        try {
            curl_setopt($this->ch, CURLOPT_URL, AZERCELL_BASE_URL . "/logout");
            curl_setopt($this->ch, CURLOPT_POST, false);
            curl_setopt($this->ch, CURLOPT_HEADER, false);
            
            curl_exec($this->ch);
            
            $this->is_logged_in = false;
            
            if (file_exists($this->cookie_file)) {
                unlink($this->cookie_file);
            }
            
            return [
                "success" => true,
                "message" => "Uğurla çıxış edildi"
            ];
            
        } catch (Exception $e) {
            return [
                "success" => false,
                "error" => "Çıxış xətası: " . $e->getMessage()
            ];
        }
    }
    
    public function isLoggedIn() {
        return $this->is_logged_in;
    }
    
    public function __destruct() {
        if ($this->ch) {
            curl_close($this->ch);
        }
    }
}

if (!is_dir("cookies")) {
    mkdir("cookies", 0755, true);
}

if (!file_exists(AZERCELL_COOKIE_FILE)) {
    touch(AZERCELL_COOKIE_FILE);
    chmod(AZERCELL_COOKIE_FILE, 0644);
}
?>
