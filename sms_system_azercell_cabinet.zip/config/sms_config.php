<?php
// SMS API konfiqurasiyası
// Bu faylı öz API məlumatlarınızla yeniləyin

// Twilio API (məşhur və etibarlı)
define('SMS_API_URL', 'https://api.twilio.com/2010-04-01/Accounts/{AccountSid}/Messages.json');
define('SMS_API_KEY', 'your_twilio_account_sid');
define('SMS_API_SECRET', 'your_twilio_auth_token');

// Və ya Nexmo/Vonage API
// define('SMS_API_URL', 'https://rest.nexmo.com/sms/json');
// define('SMS_API_KEY', 'your_nexmo_api_key');
// define('SMS_API_SECRET', 'your_nexmo_api_secret');

// Və ya yerli Azərbaycan SMS provayderi
// define('SMS_API_URL', 'https://your-provider.com/api/send');
// define('SMS_API_KEY', 'your_api_key');
// define('SMS_API_SECRET', 'your_api_secret');

// Default göndərən adı
define('DEFAULT_SENDER_ID', 'SMS');

// API provayderləri
$SMS_PROVIDERS = [
    'twilio' => [
        'name' => 'Twilio',
        'url' => 'https://api.twilio.com/2010-04-01/Accounts/{AccountSid}/Messages.json',
        'method' => 'POST',
        'auth_type' => 'basic',
        'params' => [
            'To' => 'phone',
            'From' => 'sender_id',
            'Body' => 'message'
        ]
    ],
    'nexmo' => [
        'name' => 'Nexmo/Vonage',
        'url' => 'https://rest.nexmo.com/sms/json',
        'method' => 'POST',
        'auth_type' => 'query',
        'params' => [
            'to' => 'phone',
            'from' => 'sender_id',
            'text' => 'message'
        ]
    ],
    'azercell' => [
        'name' => 'Azercell SMS Gateway',
        'url' => 'https://sms.azercell.com/api/send',
        'method' => 'POST',
        'auth_type' => 'header',
        'params' => [
            'recipient' => 'phone',
            'sender' => 'sender_id',
            'message' => 'message'
        ]
    ],
    'bakcell' => [
        'name' => 'Bakcell SMS Gateway',
        'url' => 'https://sms.bakcell.com/api/send',
        'method' => 'POST',
        'auth_type' => 'header',
        'params' => [
            'to' => 'phone',
            'from' => 'sender_id',
            'text' => 'message'
        ]
    ]
];

// Aktiv API provayderini al
function getActiveProvider() {
    try {
        $pdo = getDBConnection();
        $stmt = $pdo->prepare("SELECT * FROM api_config WHERE is_active = 1 LIMIT 1");
        $stmt->execute();
        return $stmt->fetch();
    } catch (PDOException $e) {
        return null;
    }
}

// API provayder konfiqurasiyasını yenilə
function updateApiConfig($provider, $api_url, $api_key, $api_secret, $is_active = false) {
    try {
        $pdo = getDBConnection();
        
        // Bütün provayderləri deaktiv et
        if ($is_active) {
            $stmt = $pdo->prepare("UPDATE api_config SET is_active = 0");
            $stmt->execute();
        }
        
        // Yeni konfiqurasiyanı əlavə et və ya yenilə
        $stmt = $pdo->prepare("INSERT INTO api_config (provider, api_url, api_key, api_secret, is_active) 
                               VALUES (?, ?, ?, ?, ?) 
                               ON DUPLICATE KEY UPDATE 
                               api_url = VALUES(api_url), 
                               api_key = VALUES(api_key), 
                               api_secret = VALUES(api_secret), 
                               is_active = VALUES(is_active)");
        $stmt->execute([$provider, $api_url, $api_key, $api_secret, $is_active ? 1 : 0]);
        
        return true;
    } catch (PDOException $e) {
        return false;
    }
}

// SMS qiymətləri (təxmini)
$SMS_PRICES = [
    'azercell' => [
        'local' => 0.02, // AZN per SMS
        'international' => 0.05
    ],
    'bakcell' => [
        'local' => 0.02,
        'international' => 0.05
    ],
    'twilio' => [
        'local' => 0.01, // USD per SMS
        'international' => 0.03
    ],
    'nexmo' => [
        'local' => 0.01,
        'international' => 0.03
    ]
];

// Balansı yoxla
function checkBalance() {
    try {
        $pdo = getDBConnection();
        $stmt = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'balance'");
        $stmt->execute();
        return (int)$stmt->fetchColumn();
    } catch (PDOException $e) {
        return 0;
    }
}

// Balansı yenilə
function updateBalance($new_balance) {
    try {
        $pdo = getDBConnection();
        $stmt = $pdo->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = 'balance'");
        $stmt->execute([$new_balance]);
        return true;
    } catch (PDOException $e) {
        return false;
    }
}

// Gündəlik limiti yoxla
function checkDailyLimit() {
    try {
        $pdo = getDBConnection();
        
        // Gündəlik limiti al
        $stmt = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'daily_limit'");
        $stmt->execute();
        $daily_limit = (int)$stmt->fetchColumn();
        
        // Bu gün göndərilən SMS sayını say
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM sms_logs WHERE DATE(created_at) = CURDATE() AND status = 'sent'");
        $stmt->execute();
        $sent_today = (int)$stmt->fetchColumn();
        
        return $sent_today < $daily_limit;
    } catch (PDOException $e) {
        return false;
    }
}

// Sistem statusunu yoxla
function isSystemActive() {
    try {
        $pdo = getDBConnection();
        $stmt = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'system_status'");
        $stmt->execute();
        return $stmt->fetchColumn() === 'active';
    } catch (PDOException $e) {
        return false;
    }
}
?>