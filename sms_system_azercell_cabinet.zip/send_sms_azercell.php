<?php
session_start();
require_once "config/database.php";
require_once "config/azercell_config.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.php");
    exit;
}

$phone = trim($_POST["phone"] ?? "");
$message = trim($_POST["message"] ?? "");
$sender_id = trim($_POST["sender_id"] ?? "");
$azercell_username = trim($_POST["azercell_username"] ?? "");
$azercell_password = trim($_POST["azercell_password"] ?? "");

if (empty($phone) || empty($message)) {
    $_SESSION["message"] = "Zəhmət olmasa telefon nömrəsi və mesajı doldurun!";
    $_SESSION["message_type"] = "danger";
    header("Location: index.php");
    exit;
}

if (empty($azercell_username) || empty($azercell_password)) {
    $_SESSION["message"] = "Zəhmət olmasa Azercell kabinet məlumatlarını doldurun!";
    $_SESSION["message_type"] = "danger";
    header("Location: index.php");
    exit;
}

$phone = preg_replace("/[^0-9+]/", "", $phone);

if (!preg_match("/^\+994(50|51|55|70|77|99)[0-9]{7}$/", $phone)) {
    $_SESSION["message"] = "Zəhmət olmasa düzgün Azərbaycan nömrəsi yazın! (+994501234567)";
    $_SESSION["message_type"] = "danger";
    header("Location: index.php");
    exit;
}

if (strlen($message) > 160) {
    $_SESSION["message"] = "Mesaj 160 simvoldan çox ola bilməz!";
    $_SESSION["message_type"] = "danger";
    header("Location: index.php");
    exit;
}

if (!empty($sender_id) && strlen($sender_id) > 11) {
    $_SESSION["message"] = "Göndərən adı 11 simvoldan çox ola bilməz!";
    $_SESSION["message_type"] = "danger";
    header("Location: index.php");
    exit;
}

try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    $stmt = $pdo->prepare("SELECT balance FROM system_settings WHERE id = 1");
    $stmt->execute();
    $balance = $stmt->fetchColumn();
    
    if ($balance <= 0) {
        $_SESSION["message"] = "Sistem balansı bitib! Zəhmət olmasa admin ilə əlaqə saxlayın.";
        $_SESSION["message_type"] = "warning";
        header("Location: index.php");
        exit;
    }
    
    $azercell = new AzercellCabinet();
    
    $login_result = $azercell->login($azercell_username, $azercell_password);
    
    if (!$login_result["success"]) {
        $stmt = $pdo->prepare("INSERT INTO sms_logs (phone, message, sender_id, status, api_response, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$phone, $message, $sender_id, "failed", json_encode($login_result)]);
        
        $_SESSION["message"] = "Azercell kabinetə giriş uğursuz: " . $login_result["error"];
        $_SESSION["message_type"] = "danger";
        header("Location: index.php");
        exit;
    }
    
    $sms_result = $azercell->sendSms($phone, $message, $sender_id);
    
    if ($sms_result["success"]) {
        $new_balance = $balance - 1;
        $stmt = $pdo->prepare("UPDATE system_settings SET balance = ? WHERE id = 1");
        $stmt->execute([$new_balance]);
        
        $stmt = $pdo->prepare("INSERT INTO sms_logs (phone, message, sender_id, status, api_response, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$phone, $message, $sender_id, "sent", json_encode($sms_result)]);
        
        $_SESSION["message"] = "SMS uğurla göndərildi! (Azercell Kabinet) Mesaj ID: " . $pdo->lastInsertId();
        $_SESSION["message_type"] = "success";
    } else {
        $stmt = $pdo->prepare("INSERT INTO sms_logs (phone, message, sender_id, status, api_response, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$phone, $message, $sender_id, "failed", json_encode($sms_result)]);
        
        $_SESSION["message"] = "SMS göndərilmədi: " . $sms_result["error"];
        $_SESSION["message_type"] = "danger";
    }
    
    $azercell->logout();
    
} catch (PDOException $e) {
    $_SESSION["message"] = "Sistem xətası: " . $e->getMessage();
    $_SESSION["message_type"] = "danger";
} catch (Exception $e) {
    $_SESSION["message"] = "Xəta: " . $e->getMessage();
    $_SESSION["message_type"] = "danger";
}

header("Location: index.php");
exit;
?>
