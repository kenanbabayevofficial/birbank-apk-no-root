<?php
session_start();
require_once "config/database.php";
require_once "config/azercell_config.php";

echo "<h2>SMS Debug Test</h2>";

$test_username = "test_user";
$test_password = "test_pass";
$test_phone = "+994501234567";
$test_message = "Test mesajı";
$test_sender = "Test";

echo "<h3>1. Azercell Kabinet Test</h3>";

try {
    $azercell = new AzercellCabinet();
    echo "<p><strong>Kabinet obyekti yaradıldı</strong></p>";
    
    echo "<p><strong>Login test edilir...</strong></p>";
    $login_result = $azercell->login($test_username, $test_password);
    
    echo "<pre>";
    print_r($login_result);
    echo "</pre>";
    
    if ($login_result["success"]) {
        echo "<p style=\"color: green;\"><strong>✓ Login uğurlu!</strong></p>";
        
        echo "<p><strong>Balans yoxlanılır...</strong></p>";
        $balance_result = $azercell->checkBalance();
        
        echo "<pre>";
        print_r($balance_result);
        echo "</pre>";
        
        echo "<p><strong>SMS göndərmə test edilir...</strong></p>";
        $sms_result = $azercell->sendSms($test_phone, $test_message, $test_sender);
        
        echo "<pre>";
        print_r($sms_result);
        echo "</pre>";
        
        $azercell->logout();
        echo "<p><strong>Çıxış edildi</strong></p>";
        
    } else {
        echo "<p style=\"color: red;\"><strong>✗ Login uğursuz!</strong></p>";
        echo "<p><strong>Xəta:</strong> " . $login_result["error"] . "</p>";
    }
    
} catch (Exception $e) {
    echo "<p style=\"color: red;\"><strong>Xəta:</strong> " . $e->getMessage() . "</p>";
}

echo "<h3>2. Sistem Yoxlaması</h3>";

echo "<p><strong>cURL mövcudluğu:</strong> " . (function_exists("curl_init") ? "✓ Mövcud" : "✗ Mövcud deyil") . "</p>";
echo "<p><strong>Cookie qovluğu:</strong> " . (is_dir("cookies") ? "✓ Mövcud" : "✗ Mövcud deyil") . "</p>";
echo "<p><strong>Cookie faylı:</strong> " . (file_exists("cookies/azercell_cookies.txt") ? "✓ Mövcud" : "✗ Mövcud deyil") . "</p>";

try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    echo "<p><strong>Verilənlər bazası:</strong> ✓ Qoşuldu</p>";
    
    $stmt = $pdo->prepare("SELECT balance FROM system_settings WHERE id = 1");
    $stmt->execute();
    $balance = $stmt->fetchColumn();
    echo "<p><strong>Sistem balansı:</strong> " . $balance . "</p>";
    
} catch (Exception $e) {
    echo "<p><strong>Verilənlər bazası:</strong> ✗ Xəta: " . $e->getMessage() . "</p>";
}

echo "<h3>3. Test Formu</h3>";
?>

<form method="POST" action="debug_sms.php">
    <div style="margin: 10px 0;">
        <label>İstifadəçi Adı:</label><br>
        <input type="text" name="username" value="<?php echo $test_username; ?>" style="width: 300px;">
    </div>
    <div style="margin: 10px 0;">
        <label>Şifrə:</label><br>
        <input type="password" name="password" value="<?php echo $test_username; ?>" style="width: 300px;">
    </div>
    <div style="margin: 10px 0;">
        <label>Telefon:</label><br>
        <input type="text" name="phone" value="<?php echo $test_phone; ?>" style="width: 300px;">
    </div>
    <div style="margin: 10px 0;">
        <label>Mesaj:</label><br>
        <textarea name="message" style="width: 300px; height: 100px;"><?php echo $test_message; ?></textarea>
    </div>
    <div style="margin: 10px 0;">
        <label>Göndərən:</label><br>
        <input type="text" name="sender" value="<?php echo $test_sender; ?>" style="width: 300px;">
    </div>
    <button type="submit" name="test" style="padding: 10px 20px; background: #007bff; color: white; border: none; cursor: pointer;">
        Test Et
    </button>
</form>

<?php
if (isset($_POST["test"])) {
    echo "<h3>4. Form Test Nəticəsi</h3>";
    
    $username = $_POST["username"];
    $password = $_POST["password"];
    $phone = $_POST["phone"];
    $message = $_POST["message"];
    $sender = $_POST["sender"];
    
    try {
        $azercell = new AzercellCabinet();
        
        echo "<p><strong>Login edilir...</strong></p>";
        $login_result = $azercell->login($username, $password);
        
        if ($login_result["success"]) {
            echo "<p style=\"color: green;\">✓ Login uğurlu!</p>";
            
            echo "<p><strong>SMS göndərilir...</strong></p>";
            $sms_result = $azercell->sendSms($phone, $message, $sender);
            
            echo "<pre>";
            print_r($sms_result);
            echo "</pre>";
            
            if ($sms_result["success"]) {
                echo "<p style=\"color: green;\">✓ SMS uğurla göndərildi!</p>";
            } else {
                echo "<p style=\"color: red;\">✗ SMS göndərilmədi: " . $sms_result["error"] . "</p>";
            }
            
            $azercell->logout();
            
        } else {
            echo "<p style=\"color: red;\">✗ Login uğursuz: " . $login_result["error"] . "</p>";
        }
        
    } catch (Exception $e) {
        echo "<p style=\"color: red;\">✗ Xəta: " . $e->getMessage() . "</p>";
    }
}
?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
pre { background: #f5f5f5; padding: 10px; border-radius: 5px; }
</style>
