<!DOCTYPE html>
<html lang="az">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SMS Göndər</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .sms-container {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
        }
        .form-control {
            border-radius: 10px;
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
        }
        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        .btn-send {
            background: linear-gradient(45deg, #667eea, #764ba2);
            border: none;
            border-radius: 10px;
            padding: 12px 30px;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        .btn-send:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        .phone-icon {
            color: #667eea;
            font-size: 3rem;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center align-items-center min-vh-100">
            <div class="col-md-6 col-lg-5">
                <div class="sms-container p-5">
                    <div class="text-center mb-4">
                        <i class="fas fa-sms phone-icon"></i>
                        <h2 class="fw-bold text-dark mb-2">SMS Göndər</h2>
                        <p class="text-muted">Nömrəyə mesaj göndərin</p>
                    </div>

                    <?php
                    session_start();
                    
                    // Mesaj göstərmə
                    if (isset($_SESSION['message'])) {
                        $alert_class = $_SESSION['message_type'] ?? 'info';
                        echo '<div class="alert alert-' . $alert_class . ' alert-dismissible fade show" role="alert">';
                        echo $_SESSION['message'];
                        echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
                        echo '</div>';
                        unset($_SESSION['message'], $_SESSION['message_type']);
                    }
                    ?>

                    <form action="send_sms.php" method="POST" id="smsForm">
                        <div class="mb-3">
                            <label for="phone" class="form-label fw-semibold">
                                <i class="fas fa-phone me-2"></i>Telefon Nömrəsi
                            </label>
                            <input type="tel" class="form-control form-control-lg" id="phone" name="phone" 
                                   placeholder="+994501234567" required>
                            <div class="form-text">Nömrəni beynəlxalq formatda yazın</div>
                        </div>

                        <div class="mb-3">
                            <label for="message" class="form-label fw-semibold">
                                <i class="fas fa-comment me-2"></i>Mesaj
                            </label>
                            <textarea class="form-control" id="message" name="message" rows="4" 
                                      placeholder="Mesajınızı yazın..." required maxlength="160"></textarea>
                            <div class="form-text">
                                <span id="charCount">0</span>/160 simvol
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="sender_id" class="form-label fw-semibold">
                                <i class="fas fa-user me-2"></i>Göndərən Adı
                            </label>
                            <input type="text" class="form-control" id="sender_id" name="sender_id" 
                                   placeholder="Şirkət adı və ya adınız" maxlength="11">
                            <div class="form-text">Maksimum 11 simvol</div>
                        </div>

                        <button type="submit" class="btn btn-send btn-lg w-100 text-white">
                            <i class="fas fa-paper-plane me-2"></i>SMS Göndər
                        </button>
                    </form>

                    <div class="text-center mt-4">
                        <a href="admin/login.php" class="text-decoration-none">
                            <i class="fas fa-cog me-1"></i>Admin Panel
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Simvol sayğacı
        document.getElementById('message').addEventListener('input', function() {
            const count = this.value.length;
            document.getElementById('charCount').textContent = count;
            
            if (count > 140) {
                document.getElementById('charCount').style.color = '#dc3545';
            } else {
                document.getElementById('charCount').style.color = '#6c757d';
            }
        });

        // Telefon nömrəsi formatı
        document.getElementById('phone').addEventListener('input', function() {
            let value = this.value.replace(/\D/g, '');
            if (value.startsWith('994')) {
                value = '+' + value;
            } else if (value.startsWith('0')) {
                value = '+994' + value.substring(1);
            }
            this.value = value;
        });

        // Form göndərmə
        document.getElementById('smsForm').addEventListener('submit', function(e) {
            const phone = document.getElementById('phone').value;
            const message = document.getElementById('message').value;
            
            if (!phone || !message) {
                e.preventDefault();
                alert('Zəhmət olmasa bütün sahələri doldurun!');
                return;
            }
            
            if (message.length > 160) {
                e.preventDefault();
                alert('Mesaj 160 simvoldan çox ola bilməz!');
                return;
            }
        });
    </script>
</body>
</html>