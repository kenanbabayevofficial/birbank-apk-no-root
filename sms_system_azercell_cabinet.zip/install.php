<?php
require_once 'config/database.php';

$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Verilənlər bazasını yarat
        createDatabase();
        
        // Cədvəlləri yarat
        createTables();
        
        $success = true;
        $message = 'SMS sistemi uğurla quraşdırıldı!';
        
    } catch (Exception $e) {
        $error = 'Quraşdırma xətası: ' . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="az">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SMS Sistemi Quraşdırma</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .install-container {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
        }
        .install-icon {
            color: #667eea;
            font-size: 4rem;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center align-items-center min-vh-100">
            <div class="col-md-6 col-lg-5">
                <div class="install-container p-5">
                    <div class="text-center mb-4">
                        <i class="fas fa-download install-icon"></i>
                        <h2 class="fw-bold text-dark mb-2">SMS Sistemi Quraşdırma</h2>
                        <p class="text-muted">Verilənlər bazası və cədvəllər yaradılacaq</p>
                    </div>

                    <?php if ($success): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fas fa-check-circle me-2"></i><?php echo $message; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                        
                        <div class="text-center">
                            <a href="index.php" class="btn btn-primary btn-lg">
                                <i class="fas fa-home me-2"></i>Ana Səhifəyə Get
                            </a>
                            <a href="admin/login.php" class="btn btn-outline-primary btn-lg ms-2">
                                <i class="fas fa-user-shield me-2"></i>Admin Panel
                            </a>
                        </div>
                        
                        <div class="mt-4 p-3 bg-light rounded">
                            <h6 class="fw-bold">Quraşdırılan komponentlər:</h6>
                            <ul class="mb-0">
                                <li>✅ Verilənlər bazası: <code>sms_system</code></li>
                                <li>✅ SMS logları cədvəli</li>
                                <li>✅ Sistem parametrləri cədvəli</li>
                                <li>✅ Admin istifadəçiləri cədvəli</li>
                                <li>✅ API konfiqurasiyası cədvəli</li>
                                <li>✅ Default admin hesabı</li>
                            </ul>
                        </div>
                        
                        <div class="mt-3 p-3 bg-warning rounded">
                            <h6 class="fw-bold">⚠️ Təhlükəsizlik:</h6>
                            <p class="mb-2">Quraşdırma tamamlandıqdan sonra bu faylı silin!</p>
                            <small class="text-muted">
                                <strong>Default admin giriş məlumatları:</strong><br>
                                İstifadəçi adı: <code>admin</code><br>
                                Şifrə: <code>admin123</code>
                            </small>
                        </div>
                        
                    <?php elseif ($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="fas fa-exclamation-triangle me-2"></i><?php echo $error; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                        
                        <div class="text-center">
                            <a href="install.php" class="btn btn-primary btn-lg">
                                <i class="fas fa-redo me-2"></i>Yenidən Cəhd Et
                            </a>
                        </div>
                        
                    <?php else: ?>
                        <div class="mb-4">
                            <h6 class="fw-bold">Sistem tələbləri:</h6>
                            <ul class="mb-3">
                                <li>✅ PHP 7.4 və ya yuxarı</li>
                                <li>✅ MySQL 5.7 və ya yuxarı</li>
                                <li>✅ PDO MySQL extension</li>
                                <li>✅ cURL extension</li>
                            </ul>
                            
                            <h6 class="fw-bold">Yaradılacaq cədvəllər:</h6>
                            <ul class="mb-3">
                                <li><code>sms_logs</code> - SMS göndərmə logları</li>
                                <li><code>system_settings</code> - Sistem parametrləri</li>
                                <li><code>admin_users</code> - Admin istifadəçiləri</li>
                                <li><code>api_config</code> - API konfiqurasiyası</li>
                            </ul>
                        </div>
                        
                        <form method="POST" action="">
                            <button type="submit" class="btn btn-primary btn-lg w-100">
                                <i class="fas fa-rocket me-2"></i>Sistemi Quraşdır
                            </button>
                        </form>
                        
                        <div class="text-center mt-3">
                            <a href="index.php" class="text-decoration-none">
                                <i class="fas fa-arrow-left me-1"></i>Ana Səhifəyə Qayıt
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>