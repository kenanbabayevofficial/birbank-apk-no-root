# 📱 SMS Göndərən Sayt Sistemi

PHP ilə yazılmış, nömrəyə SMS göndərə bilən tam funksional web saytı. Admin paneli, API inteqrasiyası və balans sistemi ilə.

## 🚀 Əsas Xüsusiyyətlər

### ✅ SMS Funksiyaları
- **SMS göndərmə** - Nömrəyə mesaj göndərmək
- **Sender ID** - Göndərən adını təyin etmək
- **Balans sistemi** - SMS sayını idarə etmək
- **Gündəlik limit** - Gündəlik SMS limiti
- **SMS logları** - Bütün SMS-lərin tarixçəsi

### ✅ Admin Panel
- **Dashboard** - Statistika və məlumatlar
- **SMS logları** - Bütün SMS-lərin siyahısı
- **API tənzimləmələri** - SMS provayder konfiqurasiyası
- **Sistem tənzimləmələri** - Balans, limit və digər parametrlər
- **İstifadəçi idarəetməsi** - Admin hesabları

### ✅ Təhlükəsizlik
- **Session idarəetməsi** - Təhlükəsiz giriş sistemi
- **Input validasiyası** - Məlumatların yoxlanması
- **SQL injection qorunması** - Prepared statements
- **XSS qorunması** - Məlumatların təmizlənməsi

## 📋 Sistem Tələbləri

- **PHP** 7.4 və ya yuxarı
- **MySQL** 5.7 və ya yuxarı
- **PDO MySQL** extension
- **cURL** extension
- **Web server** (Apache/Nginx)

## 🔧 Quraşdırma

### 1. Faylları yüklə
```bash
git clone https://github.com/your-username/sms-system.git
cd sms-system
```

### 2. Verilənlər bazası konfiqurasiyası
`config/database.php` faylını redaktə et:
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'sms_system');
define('DB_USER', 'your_username');
define('DB_PASS', 'your_password');
```

### 3. SMS API konfiqurasiyası
`config/sms_config.php` faylını redaktə et:
```php
define('SMS_API_URL', 'your_api_url');
define('SMS_API_KEY', 'your_api_key');
define('SMS_API_SECRET', 'your_api_secret');
```

### 4. Sistemi quraşdır
Brauzerində `install.php` səhifəsinə get və "Sistemi Quraşdır" düyməsinə bas.

### 5. Quraşdırma faylını sil
```bash
rm install.php
```

## 🔗 Dəstəklənən SMS API-ləri

### Twilio (Tövsiyə olunur)
- **Qiymət**: $0.01 per SMS
- **Ölkə dəstəyi**: Bütün ölkələr
- **API**: REST API
- **Dokumentasiya**: https://www.twilio.com/docs/sms

### Nexmo/Vonage
- **Qiymət**: $0.01 per SMS
- **Ölkə dəstəyi**: Bütün ölkələr
- **API**: REST API
- **Dokumentasiya**: https://developer.nexmo.com/api/sms

### Yerli Azərbaycan Provayderləri
- **Azercell SMS Gateway**
- **Bakcell SMS Gateway**
- **Nar SMS Gateway**

## 📊 Admin Panel

### Giriş məlumatları
- **İstifadəçi adı**: `admin`
- **Şifrə**: `admin123`

### Əsas funksiyalar
1. **Dashboard** - Statistika və məlumatlar
2. **SMS Logları** - Bütün SMS-lərin siyahısı
3. **API Tənzimləmələri** - SMS provayder konfiqurasiyası
4. **Sistem Tənzimləmələri** - Balans və limitlər
5. **İstifadəçilər** - Admin hesabları
6. **Statistika** - Detallı hesabatlar

## 🔒 Təhlükəsizlik

### Məlumatların qorunması
- Bütün məlumatlar validasiya edilir
- SQL injection qorunması
- XSS hücumlarından qorunma
- CSRF token istifadəsi

### Admin panel təhlükəsizliyi
- Session idarəetməsi
- Şifrələrin hash edilməsi
- Giriş cəhdlərinin məhdudlaşdırılması
- Təhlükəsiz çıxış

## 📱 İstifadə

### SMS göndərmək
1. Ana səhifəyə get
2. Telefon nömrəsini yaz
3. Mesajı yaz
4. Göndərən adını təyin et (istəyə görə)
5. "SMS Göndər" düyməsinə bas

### Admin panelə giriş
1. `/admin/login.php` səhifəsinə get
2. İstifadəçi adı və şifrəni yaz
3. "Giriş Et" düyməsinə bas

## 🛠️ Texniki Detallar

### Fayl strukturu
```
sms-system/
├── index.php              # Ana səhifə
├── send_sms.php           # SMS göndərmə məntiqı
├── install.php            # Quraşdırma faylı
├── config/
│   ├── database.php       # Verilənlər bazası konfiqurasiyası
│   └── sms_config.php     # SMS API konfiqurasiyası
├── admin/
│   ├── login.php          # Admin giriş
│   ├── dashboard.php      # Admin dashboard
│   └── logout.php         # Admin çıxış
└── README.md              # Bu fayl
```

### Verilənlər bazası cədvəlləri
- `sms_logs` - SMS göndərmə logları
- `system_settings` - Sistem parametrləri
- `admin_users` - Admin istifadəçiləri
- `api_config` - API konfiqurasiyası

## 💰 Qiymətləndirmə

### SMS qiymətləri (təxmini)
- **Twilio**: $0.01 per SMS
- **Nexmo**: $0.01 per SMS
- **Yerli provayderlər**: 0.02-0.05 AZN per SMS

### Hosting qiymətləri
- **Shared hosting**: $5-10/ay
- **VPS**: $10-20/ay
- **Cloud hosting**: $15-50/ay

## 🆘 Dəstək

### Tez-tez verilən suallar
1. **SMS göndərilmir?** - API konfiqurasiyasını yoxlayın
2. **Balans bitib?** - Admin paneldən balansı artırın
3. **Giriş edə bilmirəm?** - Default məlumatları istifadə edin

### Əlaqə
- **Email**: support@example.com
- **Telegram**: @support_bot
- **GitHub**: https://github.com/your-username/sms-system

## 📄 Lisenziya

Bu layihə MIT lisenziyası altında yayımlanır. Daha çox məlumat üçün `LICENSE` faylına baxın.

## 🤝 Töhfə

Layihəyə töhfə vermək istəyirsinizsə:
1. Fork edin
2. Branch yaradın
3. Dəyişiklikləri commit edin
4. Pull request göndərin

---

**Qeyd**: Bu sistem yalnız təhsil və test məqsədləri üçündür. Kommersiya məqsədləri üçün istifadə etməzdən əvvəl hüquqi tələbləri yoxlayın.