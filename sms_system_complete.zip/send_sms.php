<?php
session_start();
require_once 'config/database.php';
require_once 'config/sms_config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

// Form məlumatlarını al
$phone = trim($_POST['phone'] ?? '');
$message = trim($_POST['message'] ?? '');
$sender_id = trim($_POST['sender_id'] ?? '');

// Validasiya
if (empty($phone) || empty($message)) {
    $_SESSION['message'] = 'Zəhmət olmasa bütün sahələri doldurun!';
    $_SESSION['message_type'] = 'danger';
    header('Location: index.php');
    exit;
}

// Telefon nömrəsi formatını təmizlə
$phone = preg_replace('/[^0-9+]/', '', $phone);

// Azərbaycan nömrəsi formatını yoxla
if (!preg_match('/^\+994[0-9]{9}$/', $phone)) {
    $_SESSION['message'] = 'Zəhmət olmasa düzgün Azərbaycan nömrəsi yazın! (+994501234567)';
    $_SESSION['message_type'] = 'danger';
    header('Location: index.php');
    exit;
}

// Mesaj uzunluğunu yoxla
if (strlen($message) > 160) {
    $_SESSION['message'] = 'Mesaj 160 simvoldan çox ola bilməz!';
    $_SESSION['message_type'] = 'danger';
    header('Location: index.php');
    exit;
}

// Sender ID-ni yoxla
if (!empty($sender_id) && strlen($sender_id) > 11) {
    $_SESSION['message'] = 'Göndərən adı 11 simvoldan çox ola bilməz!';
    $_SESSION['message_type'] = 'danger';
    header('Location: index.php');
    exit;
}

try {
    // Verilənlər bazasına qoşul
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Balansı yoxla
    $stmt = $pdo->prepare("SELECT balance FROM system_settings WHERE id = 1");
    $stmt->execute();
    $balance = $stmt->fetchColumn();
    
    if ($balance <= 0) {
        $_SESSION['message'] = 'Sistem balansı bitib! Zəhmət olmasa admin ilə əlaqə saxlayın.';
        $_SESSION['message_type'] = 'warning';
        header('Location: index.php');
        exit;
    }
    
    // SMS göndərmə
    $sms_result = sendSMS($phone, $message, $sender_id);
    
    if ($sms_result['success']) {
        // Balansı azalt
        $new_balance = $balance - 1;
        $stmt = $pdo->prepare("UPDATE system_settings SET balance = ? WHERE id = 1");
        $stmt->execute([$new_balance]);
        
        // Mesajı verilənlər bazasına yaz
        $stmt = $pdo->prepare("INSERT INTO sms_logs (phone, message, sender_id, status, api_response, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$phone, $message, $sender_id, 'sent', json_encode($sms_result['response'])]);
        
        $_SESSION['message'] = 'SMS uğurla göndərildi! Mesaj ID: ' . $pdo->lastInsertId();
        $_SESSION['message_type'] = 'success';
    } else {
        // Xəta halında log yaz
        $stmt = $pdo->prepare("INSERT INTO sms_logs (phone, message, sender_id, status, api_response, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$phone, $message, $sender_id, 'failed', json_encode($sms_result['response'])]);
        
        $_SESSION['message'] = 'SMS göndərilmədi: ' . $sms_result['error'];
        $_SESSION['message_type'] = 'danger';
    }
    
} catch (PDOException $e) {
    $_SESSION['message'] = 'Sistem xətası: ' . $e->getMessage();
    $_SESSION['message_type'] = 'danger';
}

header('Location: index.php');
exit;

/**
 * SMS göndərmə funksiyası
 */
function sendSMS($phone, $message, $sender_id = '') {
    // SMS API konfiqurasiyası
    $api_url = SMS_API_URL;
    $api_key = SMS_API_KEY;
    $api_secret = SMS_API_SECRET;
    
    // Default sender ID
    if (empty($sender_id)) {
        $sender_id = DEFAULT_SENDER_ID;
    }
    
    // API parametrləri
    $params = [
        'to' => $phone,
        'message' => $message,
        'from' => $sender_id
    ];
    
    // cURL ilə API-yə sorğu göndər
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $api_key,
        'Content-Type: application/x-www-form-urlencoded'
    ]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error) {
        return [
            'success' => false,
            'error' => 'cURL xətası: ' . $error,
            'response' => null
        ];
    }
    
    // Response-u parse et
    $result = json_decode($response, true);
    
    if ($http_code === 200 && isset($result['success']) && $result['success']) {
        return [
            'success' => true,
            'error' => null,
            'response' => $result
        ];
    } else {
        $error_msg = isset($result['message']) ? $result['message'] : 'Naməlum xəta';
        return [
            'success' => false,
            'error' => $error_msg,
            'response' => $result
        ];
    }
}
?>