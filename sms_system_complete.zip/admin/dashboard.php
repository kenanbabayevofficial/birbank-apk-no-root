<?php
session_start();
require_once '../config/database.php';

// Giriş yoxlaması
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

try {
    $pdo = getDBConnection();
    
    // Statistika məlumatları
    $stats = [];
    
    // Ümumi SMS sayı
    $stmt = $pdo->query("SELECT COUNT(*) FROM sms_logs");
    $stats['total_sms'] = $stmt->fetchColumn();
    
    // Uğurlu SMS sayı
    $stmt = $pdo->query("SELECT COUNT(*) FROM sms_logs WHERE status = 'sent'");
    $stats['sent_sms'] = $stmt->fetchColumn();
    
    // Uğursuz SMS sayı
    $stmt = $pdo->query("SELECT COUNT(*) FROM sms_logs WHERE status = 'failed'");
    $stats['failed_sms'] = $stmt->fetchColumn();
    
    // Bu gün göndərilən SMS
    $stmt = $pdo->query("SELECT COUNT(*) FROM sms_logs WHERE DATE(created_at) = CURDATE() AND status = 'sent'");
    $stats['today_sms'] = $stmt->fetchColumn();
    
    // Balans
    $stmt = $pdo->query("SELECT setting_value FROM system_settings WHERE setting_key = 'balance'");
    $stats['balance'] = $stmt->fetchColumn();
    
    // Son 10 SMS
    $stmt = $pdo->query("SELECT * FROM sms_logs ORDER BY created_at DESC LIMIT 10");
    $recent_sms = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $error = 'Verilənlər bazası xətası: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="az">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - SMS Sistemi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar-brand {
            font-weight: 700;
        }
        .sidebar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: white;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 12px 20px;
            border-radius: 8px;
            margin: 2px 0;
            transition: all 0.3s ease;
        }
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            color: white;
            background: rgba(255, 255, 255, 0.1);
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
        }
        .stat-card {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
        }
        .stat-card.success {
            background: linear-gradient(45deg, #28a745, #20c997);
        }
        .stat-card.warning {
            background: linear-gradient(45deg, #ffc107, #fd7e14);
        }
        .stat-card.danger {
            background: linear-gradient(45deg, #dc3545, #e83e8c);
        }
        .table {
            border-radius: 10px;
            overflow: hidden;
        }
        .btn-logout {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: white;
        }
        .btn-logout:hover {
            background: rgba(255, 255, 255, 0.2);
            color: white;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0">
                <div class="sidebar p-3">
                    <div class="text-center mb-4">
                        <i class="fas fa-sms fa-2x mb-2"></i>
                        <h5 class="mb-0">SMS Sistemi</h5>
                        <small>Admin Panel</small>
                    </div>
                    
                    <nav class="nav flex-column">
                        <a class="nav-link active" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                        <a class="nav-link" href="sms_logs.php">
                            <i class="fas fa-list me-2"></i>SMS Logları
                        </a>
                        <a class="nav-link" href="api_settings.php">
                            <i class="fas fa-cog me-2"></i>API Tənzimləmələri
                        </a>
                        <a class="nav-link" href="system_settings.php">
                            <i class="fas fa-sliders-h me-2"></i>Sistem Tənzimləmələri
                        </a>
                        <a class="nav-link" href="users.php">
                            <i class="fas fa-users me-2"></i>İstifadəçilər
                        </a>
                        <a class="nav-link" href="statistics.php">
                            <i class="fas fa-chart-bar me-2"></i>Statistika
                        </a>
                    </nav>
                    
                    <div class="mt-auto pt-4">
                        <div class="text-center mb-3">
                            <small class="text-white-50">
                                <i class="fas fa-user me-1"></i>
                                <?php echo htmlspecialchars($_SESSION['admin_name']); ?>
                            </small>
                        </div>
                        <a href="logout.php" class="btn btn-logout w-100">
                            <i class="fas fa-sign-out-alt me-2"></i>Çıxış
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 px-4 py-3">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2 class="mb-0">
                        <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                    </h2>
                    <a href="../index.php" class="btn btn-outline-primary">
                        <i class="fas fa-external-link-alt me-2"></i>Ana Səhifə
                    </a>
                </div>
                
                <!-- Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-md-3 mb-3">
                        <div class="card stat-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h3 class="mb-0"><?php echo number_format($stats['total_sms']); ?></h3>
                                        <p class="mb-0">Ümumi SMS</p>
                                    </div>
                                    <div class="align-self-center">
                                        <i class="fas fa-sms fa-2x"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-3">
                        <div class="card stat-card success">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h3 class="mb-0"><?php echo number_format($stats['sent_sms']); ?></h3>
                                        <p class="mb-0">Uğurlu SMS</p>
                                    </div>
                                    <div class="align-self-center">
                                        <i class="fas fa-check-circle fa-2x"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-3">
                        <div class="card stat-card warning">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h3 class="mb-0"><?php echo number_format($stats['today_sms']); ?></h3>
                                        <p class="mb-0">Bu Gün</p>
                                    </div>
                                    <div class="align-self-center">
                                        <i class="fas fa-calendar-day fa-2x"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-3">
                        <div class="card stat-card danger">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h3 class="mb-0"><?php echo number_format($stats['balance']); ?></h3>
                                        <p class="mb-0">Balans</p>
                                    </div>
                                    <div class="align-self-center">
                                        <i class="fas fa-wallet fa-2x"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Recent SMS -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-clock me-2"></i>Son SMS-lər
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th>ID</th>
                                        <th>Nömrə</th>
                                        <th>Mesaj</th>
                                        <th>Göndərən</th>
                                        <th>Status</th>
                                        <th>Tarix</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recent_sms as $sms): ?>
                                    <tr>
                                        <td>#<?php echo $sms['id']; ?></td>
                                        <td><?php echo htmlspecialchars($sms['phone']); ?></td>
                                        <td>
                                            <span class="text-truncate d-inline-block" style="max-width: 200px;" 
                                                  title="<?php echo htmlspecialchars($sms['message']); ?>">
                                                <?php echo htmlspecialchars($sms['message']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlspecialchars($sms['sender_id'] ?: 'Default'); ?></td>
                                        <td>
                                            <?php if ($sms['status'] === 'sent'): ?>
                                                <span class="badge bg-success">Göndərildi</span>
                                            <?php elseif ($sms['status'] === 'failed'): ?>
                                                <span class="badge bg-danger">Uğursuz</span>
                                            <?php else: ?>
                                                <span class="badge bg-warning">Gözləyir</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo date('d.m.Y H:i', strtotime($sms['created_at'])); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <?php if (empty($recent_sms)): ?>
                        <div class="text-center py-4">
                            <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                            <p class="text-muted">Hələ SMS göndərilməyib</p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>