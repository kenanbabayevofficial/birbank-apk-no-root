<?php
// Verilənlər bazası konfiqurasiyası
define('DB_HOST', 'localhost');
define('DB_NAME', 'sms_system');
define('DB_USER', 'root');
define('DB_PASS', '');

// PDO konfiqurasiyası
define('DB_CHARSET', 'utf8mb4');
define('DB_COLLATE', 'utf8mb4_unicode_ci');

// Verilənlər bazası qoşulma funksiyası
function getDBConnection() {
    try {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $pdo = new PDO($dsn, DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        return $pdo;
    } catch (PDOException $e) {
        die("Verilənlər bazası xətası: " . $e->getMessage());
    }
}

// Verilənlər bazası cədvəllərini yarat
function createTables() {
    try {
        $pdo = getDBConnection();
        
        // SMS logları cədvəli
        $pdo->exec("CREATE TABLE IF NOT EXISTS sms_logs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            phone VARCHAR(20) NOT NULL,
            message TEXT NOT NULL,
            sender_id VARCHAR(11) DEFAULT NULL,
            status ENUM('sent', 'failed', 'pending') NOT NULL,
            api_response TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_phone (phone),
            INDEX idx_status (status),
            INDEX idx_created_at (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        
        // Sistem parametrləri cədvəli
        $pdo->exec("CREATE TABLE IF NOT EXISTS system_settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            setting_key VARCHAR(50) UNIQUE NOT NULL,
            setting_value TEXT,
            description TEXT,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        
        // Admin istifadəçiləri cədvəli
        $pdo->exec("CREATE TABLE IF NOT EXISTS admin_users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            email VARCHAR(100) UNIQUE NOT NULL,
            full_name VARCHAR(100) NOT NULL,
            role ENUM('admin', 'moderator') DEFAULT 'moderator',
            is_active BOOLEAN DEFAULT TRUE,
            last_login TIMESTAMP NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        
        // API konfiqurasiyası cədvəli
        $pdo->exec("CREATE TABLE IF NOT EXISTS api_config (
            id INT AUTO_INCREMENT PRIMARY KEY,
            provider VARCHAR(50) NOT NULL,
            api_url VARCHAR(255) NOT NULL,
            api_key VARCHAR(255) NOT NULL,
            api_secret VARCHAR(255) DEFAULT NULL,
            is_active BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        
        // Default məlumatları əlavə et
        $stmt = $pdo->prepare("INSERT IGNORE INTO system_settings (setting_key, setting_value, description) VALUES 
            ('balance', '100', 'Sistem balansı (SMS sayı)'),
            ('default_sender_id', 'SMS', 'Default göndərən adı'),
            ('max_message_length', '160', 'Maksimum mesaj uzunluğu'),
            ('daily_limit', '1000', 'Gündəlik SMS limiti'),
            ('system_status', 'active', 'Sistem statusu')
        ");
        $stmt->execute();
        
        // Default admin istifadəçisi
        $stmt = $pdo->prepare("INSERT IGNORE INTO admin_users (username, password, email, full_name, role) VALUES 
            ('admin', ?, 'admin@sms.com', 'System Administrator', 'admin')
        ");
        $stmt->execute([password_hash('admin123', PASSWORD_DEFAULT)]);
        
        // Default API konfiqurasiyası
        $stmt = $pdo->prepare("INSERT IGNORE INTO api_config (provider, api_url, api_key, api_secret, is_active) VALUES 
            ('twilio', 'https://api.twilio.com/2010-04-01/Accounts/{AccountSid}/Messages.json', 'your_api_key', 'your_api_secret', FALSE),
            ('nexmo', 'https://rest.nexmo.com/sms/json', 'your_api_key', 'your_api_secret', FALSE)
        ");
        $stmt->execute();
        
        return true;
    } catch (PDOException $e) {
        die("Cədvəl yaratma xətası: " . $e->getMessage());
    }
}

// Verilənlər bazasını yarat (əgər yoxdursa)
function createDatabase() {
    try {
        $pdo = new PDO("mysql:host=" . DB_HOST, DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        $pdo->exec("CREATE DATABASE IF NOT EXISTS " . DB_NAME . " CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        
        return true;
    } catch (PDOException $e) {
        die("Verilənlər bazası yaratma xətası: " . $e->getMessage());
    }
}
?>